mariadb
=======

A Puppet module for managing MariaDB.

NOTE: all the useful bits from this module been merged into the "mysql" module, 
and this module is now deprecated.
