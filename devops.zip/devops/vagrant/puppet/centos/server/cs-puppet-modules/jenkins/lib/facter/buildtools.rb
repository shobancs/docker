# returns list of buildtools
Facter.add('buildtools') do
  confine :kernel => :linux
  setcode do
    tools = []
    begin
      Dir.entries("/bms/webapps/jenkins/label").each do |tool|
        tool.strip!
        next if tool == "."
        next if tool == ".."
        tools << tool
      end
      rescue Exception => e
        Facter.debug("An exception occurred while trying to read /bms/tools: #{e.message}")
          nil
        end
      tools.sort.uniq.join(',')
    end
end
