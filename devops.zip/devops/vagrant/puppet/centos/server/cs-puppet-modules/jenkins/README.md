# Jenkins Module Configuration
==========

You should use this module to manage jenkins public slaves or shared masters.

### Master Class Parameters
This class accepts a few parameters and none are required. Invoking this class
will create install the jenkins.sh script and the jenkins service.

| parameter | default | optional |
|:---------:|:-------:|:--------:|
| url_prefix | '/jenkins' | Y |
| http_port  | '9001' | Y |
| ajp_port  | '9501' | Y |
| java_xms  | '6G' | Y |
| java_xmx  | '6G' | Y |
| java_metaspace | '1G' | Y |
| is_ha | false | Y |


**url_prefix** - Jenkins url prefix
**http_port** - Port for jenkins master to listen on  
**ajp_port** - Port for jenkins to listen for AJP connections
**java_xms** - java minimum memory
**java_xmx** - java maximum memory
**java_metaspace** - java metaspace size
**is_ha** - Should puppet setup jgroups.xml file?  

### Example Master Class
```
    class { '::jenkins::master' :
      url_prefix     => '/jenkins',
      http_port      => '9001',
      ajp_port       => '9501',
      java_xms       => '6g',
      java_xmx       => '6g',
      java_metaspace => '1g',
      is_ha          => false,
    }
```

### Agent Class Parameters
This class accepts a few parameters but only two are required: jenkins_master
and credentials. Invoking this class will install the jenkins-cli and then register
the node with the specified master causing it to ssh to the node and start the slave.jar

| parameter | default | optional |
|:---------:|:-------:|:--------:|
| port | 22 | Y |
| java_xms | 1G | Y |
| java_xmx | 2G | Y |
| executors | 1 | Y |
| mode | normal | Y |
| label | N/A | Y |
| credentials | N/A | N |
| jenkins_master | N/A | N |

**port** - The port the jenkins master should connect to.
**java_xms - The miniumum java memory
**java_xmx** - The Maximum java memory.
**executors** - The number of executors. If left blank it will be based on the processorcount:
   1 processor = 1 executor
   multi-processor = processorcount - 1 * 2  
**mode** - Slave mode, choices are:
 normal - Utilize this slave as much as possible
 exclusive - Only run tied jobs
 **label** - Labels to tag the slave with. If left empty, puppet will create a
   default label of facts: $::site_linux_$::operatingsystemmajrelease_$::vmsize
**credentials** - Required credentials UUID that the master will use to ssh into
  the slave and start the jenkins agent
**jenkins_master** - the url of the jenkins master to register with

### Example Agent Class
```
    jenkins::agent' :
      port           = 22,
      java_xms       = '1G'  
      java_xmx       = '2G',
      executors      = 1,
      credentials    = '1234-1234-1234-1234',
      jenkins_master = 'http://jenkins.example.com:8080',
    }
```
