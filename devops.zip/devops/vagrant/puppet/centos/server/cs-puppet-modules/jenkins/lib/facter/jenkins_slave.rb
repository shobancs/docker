# returns a true string id the jenkins label directory exists.
# this directory is created by the jenkins::agent class
Facter.add('jenkins_slave') do
  confine :kernel => :linux
  setcode do
    begin
      if File.exists?("/bms/webapps/jenkins/label")
        'true'
      else
        'false'
      end
    end
  end
end
