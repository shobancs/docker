# Puppet Module Configuration
==========

You should use this module to manage the puppet agent on a node. The module only accepts
two variables: server_name and ca_server. Both have defaults that point to our current
servers.

```
class { '::puppet':
  server_name => 'cpe-tcon-idev3-01.cisco.com',
  ca_server   => 'cpe-mcomp-idev3-01.cisco.com',
}
```

Once the class is applied to a node it will insure the puppet software id installed on the node,
it will confgure the agent, and then it will ensure the agent is always running.


#### Adding a node

1. Log into the server and run the following command:

```
user@host $ sudo puppet agent -t --server=cpe-tcon-idev3-01.cisco.com --ca_server=cpe-mcomp-idev3-01.cisco.com
```

2. Get the puppet agent cert signed.
3. Add the profiles::pds_system class to the node in foreman.
4. Run the above puppet agent command a second time
