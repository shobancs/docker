# Orion_scripts module

This module installs the Orion scripts for a JMM host.
Mostly it just uses yum to install the orion rpm, but it also
sets up some prerequisites.

## Required Forman Parameters

In order to use this module, the modules pdsint and bms_repos::bms_yum must be included for the host.  
