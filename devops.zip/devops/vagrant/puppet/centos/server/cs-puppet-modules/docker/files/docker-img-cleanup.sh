#!/bin/bash

#For JMM Host, docker-img-cleanup.sh true -1 7 7 
#For Slave,    docker-img-cleanup.sh false 7 2 7 

# Flags:

# A boolean value. If true, will keep latest images even if not in use. If false, will treat latest images the same as other images.
keep_latest=$1 

if [ $keep_latest = true -o  $keep_latest = false ]; then
	echo "keep_latest=$keep_latest"
else
	echo "keep_latest is missing or incorrect. Should be a boolean value. Abort."
	exit 1
fi

# The age after which to stop running containers. Setting it to -1 will never stop a running container.
days_stop_running_container=$2

if [ "$days_stop_running_container" != "" ]; then
	echo "days_stop_running_container=$days_stop_running_container"
else
	echo "days_stop_running_container is missing. Abort."
	exit 1
fi

# The age after which to remove stopped containers. 
days_remove_stopped_container=$3

if [ "$days_remove_stopped_container" != "" ]; then
	echo "days_remove_stopped_container=$days_remove_stopped_container"
else
	echo "days_remove_stopped_container is missing. Abort."
	exit 1
fi

# The age after which to remove unused images.
days_remove_unused_image=$4

if [ "$days_remove_unused_image" != "" ]; then
	echo "days_remove_unused_image=$days_remove_unused_image"
else
	echo "days_remove_unused_image is missing. Abort."
	exit 1
fi

# Shell function to check if a date is more than x days in the past.
# Dates can be in old format "2016-02-26 01:38:47.318442457 +0000 UTC"
# or new format "2016-02-26T01:38:47.1234Z"
# Usage:  if isOlderThanXDays $exitTime $days; then ...
isOlderThanXDays() {
    date="$1"
	days=$2
    date=${date%% *}           # Remove everything after first space
    date=${date%%T*}           # Also everything after first 'T'
    date=${date//-/}           # Remove all dashes, leaving yyyymmdd
    toDate=$(date -d "now - $days days" +"%Y%m%d")

    # Return result of comparison as success/fail
    [ $date -le $toDate ]
}


# Stop running containers with ages older than $days_stop_running_container days
# Skip this step if $days_stop_running_container = -1
if [ $days_stop_running_container -gt 0 ]; then
	echo "Trying to stop containers that have been running more than $days_stop_running_container days."
	running=$(docker ps -q)
	if [ "${running}" != "" ]; then
		for i in $running; do
			container_started_at=$(docker inspect  -f '{{.State.StartedAt}}' $i)
			if isOlderThanXDays "$container_started_at" $days_stop_running_container; then
				echo "Stopping container $i"
				docker stop $i
			else
				echo "Container $i is not $days_stop_running_container days old yet. Skip it."
			fi
		done
	else
		echo "No running containers found."
	fi
		
else
	echo "days_stop_running_container is disabled. Will not stop any running container."
fi


dead=$(docker ps -q -f "status=dead")
if [ "${dead}" != "" ]; then
   echo "Removing dead containers: ${dead}"
   docker rm -v ${dead}
else
   echo "No dead containers to delete"
fi

exited=$(docker ps -q -f "status=exited")
if [ "${exited}" != "" ]; then
   for i in $exited; do
      # Find when container was exited
      containerExitTime=$(docker inspect -f '{{ .State.FinishedAt }}' $i)
      if isOlderThanXDays "$containerExitTime" $days_remove_stopped_container; then
         echo "Removing exited container ${i}"
         docker rm -v ${i}
      else
         echo "Not removing exited container ${i}.  Not dead $days_remove_stopped_container days yet."
      fi
   done
else
   echo "No exited containers to delete"
fi

declare -A usedimages

if [ $keep_latest = true ]; then
	echo "keep_latest is enabled. Trying to preserve latest images."
	# Get list of images tagged "latest".  Need to preserve all such images.
	# Key is (truncated) image ID; value is image tag.
	echo "Get list of images that are tagged latest"
	rm -f /tmp/docker-img-cleanup.images
	docker images >/tmp/docker-img-cleanup.images
	while read iname itag iid irest; do
		if [ "$itag" == "latest" ]; then
			usedimages[$iid]="${iname}:${itag}"
		fi
	done </tmp/docker-img-cleanup.images

	# WARNING: Cannot pipe output of docker images into the while loop above.
	# If you do, the while loop runs in a sub-shell and the assignments to
	# usedimages are lost.
else
	echo "keep_latest is disabled. Latest images will be treated the same as other images."
fi


# get list of images that are used by running containers.
# Key is first 12 char of image ID; value is container name
# Get history of each container in case some ancestors are labeled (below)
echo "Get list of images that are used by running containers"
for conid in $(docker ps -aq); do
   name=$(docker inspect --format="{{.Name}}" $conid)
   imgid=$(docker inspect  --format="{{.Image}}" $conid)
   imgid=${imgid:0:12}
   for id2 in $(docker history -q $imgid); do
      usedimages[$id2]=$name
   done
done


# Printing contents of usedimages.
# ${!array[@]} is list of keys; ${array[@]} is values.
#for i in "${!usedimages[@]}"; do
#   echo "image id: $i      container name: ${usedimages[$i]}"
#done

# Check whether an image is in use.
# test ('[') just sets return code, which is what I need.
function image_in_use() {
    [ -n "${usedimages[$1]}" ]
}

# WARNING: dangling container (one labeled <none>:<none> can be in-use if
# an image with the same label and version was downloaded or built - common if
# image is xxx:latest.  So must check image ID against in use images.
dangling=$(docker images -f "dangling=true" -q)
if [ "${dangling}" != "" ]; then
   for img in ${dangling}; do
      if image_in_use "$img"; then
         echo "Dangling image $img is in use by container ${usedimages[$img]}"
      else
         echo "Removing dangling image ${img}"
         docker rmi ${img}
      fi
   done
else
   echo "No dangling images to delete"
fi

echo "Removing unused images"
for i in $(docker images -q | sort -u); do
   if image_in_use "$i"; then
      echo "Image $i is used by container ${usedimages[$i]}"
   else
      #Check if image is older than 7 days
      imageCreateTime=$(docker inspect -f '{{ .Created }}' $i)
      if isOlderThanXDays "$imageCreateTime" $days_remove_unused_image; then
         echo "Removing unused image: $i"
         # -f is needed in case image has multiple tags.  Is safe as in-use check is now reliable.
         docker rmi -f $i
      else
         echo "Image is not old enough to be deleted: $i"
      fi
   fi
done