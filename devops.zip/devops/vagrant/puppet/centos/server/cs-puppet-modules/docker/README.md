# docker
module to update yum repo and install docker for Redhat family OS
