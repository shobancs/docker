# Profiles Module Configuration
==========

You should use this module to create configuration for your application. Each class should inherit 'profiles' and
take no parameters. The base class (init.pp) has a few requires that every host should have. The manifest you write
should be a complete 'profile' of your application.

```
class profiles::my_application inherits profiles {
```
#### Module Guidelines

You may notice classes begin with '::', this specifies the puppet 'top-scope'. If you leave this off your classes,
puppet will look for a profiles::class_name before looking in modules/class_name. This will cause you to get the 
wrong manifest applied to your host. 

The reason your class should take no paramaters is because they should be dynamic lookups.

Hiera is a key/value lookup tool for configuration data, built to make Puppet better and let you set node-specific 
data without repeating yourself. 

$variable = hiera($variable)

A complete walkthrough is here: https://docs.puppet.com/hiera/3.2/complete_example.html

In order to do dynamic lookups you will need to checkout the hieradata git repository and add some yaml files to it.

#### Example Manifest


```
# artifactory.pp - installs and artifactory node

class profiles::artifactory {
  include ::bms_repos::bms_yum
  include ::encgi_users::pdsint
  
  class { '::artifactory' :
    $version         = '4.8.3',
    $arti_user       = hiera($arti_user),
    $xms             = hiera($arti_xms),
    $xmx             = hiera($arti_xmx),
    $jmx_port        = hiera($arti_jmx),
    $is_ha           = hiera($arti_ha),
    $membership_port = hiera($artie_member_port),
  }
 
}
```
