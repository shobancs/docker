#!/bin/bash
# 
# $1: master
# $2: site 
# $3: port 
# $4: fqdn 
# $5: hostname

BASE_URL="http://localhost/$1/check_mk/webapi.py"
USER="apiuser"
PASS=`cat /omd/sites/$1/var/check_mk/web/$USER/automation.secret`

# Add the host
ADD_PAYLOAD="request={ \"attributes\": { \"site\": \"$2\" }, \"folder\":\"$2\", \"hostname\": \"$5\" }"
curl "$BASE_URL?action=add_host&_username=$USER&_secret=$PASS" -d "$ADD_PAYLOAD"

# Discover services
DISC_PAYLOAD="request={\"hostname\": \"$5\"}"
curl "$BASE_URL?action=discover_services&_username=$USER&_secret=$PASS&mode=refresh" -d "$DISC_PAYLOAD"

# Activate changes
curl "$BASE_URL?action=activate_changes&_username=$USER&_secret=$PASS"
