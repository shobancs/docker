#!/usr/bin/env python
#
# This script is called by the Check MK Event Console to 
# create, update, and resolve Cachet incidents. The script 
# accepts the following parameters:
# 
# cachet.py <action> <component> <state>
# 
# The available actions are status or ack. A status creates an incident
# based on the current service/component state. A state of 0 (OK)
# sets the Cachet component to Fixed and a state of 2 (CRITICAL) sets
# the component to Major Outage. We are not currently using component status 
# for Performance Issues or Partial Outage.
# 
#  Examples:
#    Create a new "identified" Major Outage incident:
#        cachet.py status gitlfs.cisco.com 2
#        
#    Advance the identified incident to under investigation:
#        cachet.py ack gitlfs.cisco.com 2
#        
#    Mark the component as operational and the incident as fixed:
#        cachet.py status gitlfs.cisco.com 0

# Requirements:
# - pip install python-cachetclient
# - This script should be installed to /omd/sites/master/local/bin

import os
import sys
import json

import cachetclient.cachet as cachet

ENDPOINT  = '<%= @cachet_endpoint %>'
API_TOKEN = '<%= @cachet_api_token %>'

# A state change to critical creates a new incident
# An acknowledgment adds an update to say we are investigating
# A state change to ok adds a update to say the issue is fixed.
STATUS = {
    'incident': {
        'create':  2,  # Identified
        'resolve': 4,  # Fixed
        'update':  1,  # Investigating
    },
    'action': {
        'create':  "Issue Detected",
        'update':  "Issue Update",
        'resolve': "Issue Resolved",
    },
    'message': {
        'create':  "We have detected an issue with this service and our support engineers have been notified.",
        'update':  "We are currently investigating this issue and will provide an update shortly.",
        'resolve': "This issue has been resolved at this time. We will continue to investigate the root cause.",
    },
    'state': {
        0: 1,
        1: 3,
        2: 4
    }
}

def create_incident(**kwargs):

    incidents = cachet.Incidents(endpoint=ENDPOINT, api_token=API_TOKEN)

    if 'component_id' in kwargs:
        return incidents.post(name=kwargs['name'],
                              message=kwargs['message'],
                              status=kwargs['status'],
                              component_id=kwargs['component_id'],
                              component_status=kwargs['component_status'])
    else:
        return incidents.post(name=kwargs['name'],
                              message=kwargs['message'],
                              status=kwargs['status'])


def get_component_by_name(name):
    components = cachet.Components(endpoint=ENDPOINT)
    component = json.loads(components.get(name=name))
    return component['data']


if __name__ == '__main__':

    action      = sys.argv[1]
    service     = sys.argv[2]
    state       = int(sys.argv[3])
    last_id     = False
    last_status = False
    status_key  = False

    component = get_component_by_name(service)

    if not component:
        sys.exit()

    # Get the last incident for this component
    incident = json.loads(cachet.Incidents(endpoint=ENDPOINT).get(component_id=component[0]['id'], per_page=1, sort='id', order='desc'))

    if incident['meta']['pagination']['count']:
        last_id     = incident['data'][0]['id']
        last_status = int(incident['data'][0]['status'])


    if action == 'status':

         if state == 2 and (last_status is False or last_status == 4):
            status_key = 'create'
        
         if state == 0 and last_status != 4:
            status_key = 'resolve'
        
    elif action == 'ack':
        if state == 2 and last_status is not False and last_status != 1:
            status_key = 'update'

    # If we have an status_key create an incident record
    if status_key is not False:
        create_incident(name=STATUS['action'][status_key],
                        message=STATUS['message'][status_key],
                        status=STATUS['incident'][status_key],
                        component_id=component[0]['id'],
                        component_status=STATUS['state'][state])

