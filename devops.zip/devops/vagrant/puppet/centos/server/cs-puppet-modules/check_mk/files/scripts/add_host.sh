#!/bin/bash
# 
# $1: site
# $2: fqdn 
# $3: hostname 
# $4: environment 
# $5: site 
# $6 host_group

BASE_URL="http://localhost/$1/check_mk/webapi.py"
USER="apiuser"
PASS=`cat /omd/sites/$1/var/check_mk/web/$USER/automation.secret`

# Add the host
ADD_PAYLOAD="request={ \"attributes\": { \"site\": \"$5\" }, \"folder\":\"$5\", \"hostname\": \"$3\" }"
curl "$BASE_URL?action=add_host&_username=$USER&_secret=$PASS" -d "$ADD_PAYLOAD"

# Discover services
DISC_PAYLOAD="request={\"hostname\": \"$3\"}"
curl "$BASE_URL?action=discover_services&_username=$USER&_secret=$PASS&mode=refresh" -d "$DISC_PAYLOAD"

# Activate changes
curl "$BASE_URL?action=activate_changes&_username=$USER&_secret=$PASS"
