#!/bin/bash
#
# Kills all processes for a given user if the home
# directory of that user is not what is expected
#

EXPECTED=$1
USERNAME=$2

if [ "$EXPECTED" != "$(eval echo "~baas")" ]; then
  killall -u $USERNAME
fi
