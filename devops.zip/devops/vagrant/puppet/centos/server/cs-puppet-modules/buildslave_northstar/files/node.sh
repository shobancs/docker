#!/bin/bash

DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
LOG=$DIR/log-add-worker-node.log

JENKINS_MASTER_URL=$1
#FOLDER=$2
NAME=$2

echo "JENKINS_MASTER_URL =$JENKINS_MASTER_URL=" >> $LOG
#echo "FOLDER =$FOLDER=" >> $LOG
echo "NAME =$NAME=" >> $LOG
echo "DIR =$DIR=" >> $LOG

echo "---------- Run on `date` ---------" >> $LOG

#  used to use:  $FOLDER/$NAME

echo "will do: java -jar $DIR/jenkins-cli.jar -s $JENKINS_MASTER_URL -i $DIR/.key get-node $NAME &> $DIR/node-old.xml" >> $LOG
java -jar $DIR/jenkins-cli.jar -s $JENKINS_MASTER_URL -i $DIR/.key get-node $NAME &> $DIR/node-old.xml

if [ "$?" != "0" ]; then
    echo "Provisioning new slave" >> $LOG
    echo "will do: cat $DIR/node.xml | java -jar $DIR/jenkins-cli.jar -s $JENKINS_MASTER_URL -i $DIR/.key create-node $NAME 2>&1" >> $LOG
    echo $(cat $DIR/node.xml | java -jar $DIR/jenkins-cli.jar -s $JENKINS_MASTER_URL -i $DIR/.key create-node $NAME 2>&1) >> $LOG
else
    echo "Not Replacing existing slave" >> $LOG
    diff $DIR/node-old.xml $DIR/node.xml >> $LOG
#    echo $(cat $DIR/node.xml | java -jar $DIR/jenkins-cli.jar -s $JENKINS_MASTER_URL -i $DIR/.key update-job $NAME 2>&1) >> $LOG
fi

exit 0
