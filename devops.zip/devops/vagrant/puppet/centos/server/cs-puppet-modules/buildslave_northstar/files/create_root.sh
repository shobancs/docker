#!/bin/bash

INSTALL_BASE=$1

if [ "$INSTALL_BASE" == "" ]; then
  echo "Must specify an install_base path"
  exit 1
fi

if [ -e "$INSTALL_BASE" ] && [ ! -L "$INSTALL_BASE" ]; then
  echo "*** Error - $INSTALL_BASE must be a link and not an actual folder!"
  exit 1
fi

test -d /nobackup && test ! -d /nobackup/$INSTALL_BASE && mkdir -p /nobackup/$INSTALL_BASE
test -d /nobackup && test ! -L $INSTALL_BASE && ln -s /nobackup/$INSTALL_BASE/ $INSTALL_BASE

test -d /data && test ! -d /data/$INSTALL_BASE && mkdir -p /data/$INSTALL_BASE
test -d /data && test ! -L $INSTALL_BASE && ln -s /data/$INSTALL_BASE/ $INSTALL_BASE

test -d /misc && test ! -d /misc/$INSTALL_BASE && mkdir -p /misc/$INSTALL_BASE
test -d /misc && test ! -L $INSTALL_BASE && ln -s /misc/$INSTALL_BASE/ $INSTALL_BASE

exit 0
