# buildslave_northstar

Bootstraps a Jenkins build slave. Sets up `baas` user's home directory and installed the `run` binary.
