#!/bin/bash

if [ -e /etc/init.d/appdyn-machineagent ];
then
    service appdyn-machineagent stop
    chkconfig appdyn-machineagent off
    rm -f /etc/init.d/appdyn-machineagent
fi

if [ -e /etc/init.d/appdyn-machineagent--JenMasPrd ];
then
    service appdyn-machineagent--JenMasPrd stop
    chkconfig appdyn-machineagent--JenMasPrd off
    rm -f /etc/init.d/appdyn-machineagent--JenMasPrd
fi

if [ -e /etc/init.d/appdyn-machineagent--JenMasStg ];
then
    service appdyn-machineagent--JenMasStg stop
    chkconfig appdyn-machineagent--JenMasStg off
    rm -f /etc/init.d/appdyn-machineagent--JenMasStg
fi

if [ -e /etc/init.d/appdyn-machineagent--ArtiPrd ];
then
    service appdyn-machineagent--ArtiPrd stop
    chkconfig appdyn-machineagent--ArtiPrd off
    rm -f /etc/init.d/appdyn-machineagent--ArtiPrd
fi

if [ -e /etc/init.d/appdyn-machineagent-jenkins ];
then
    service appdyn-machineagent-jenkins stop
    chkconfig appdyn-machineagent-jenkins off
    rm -f /etc/init.d/appdyn-machineagent-jenkins
fi

if [ -e /etc/init.d/appdyn-machineagent-kafka ];
then
    service appdyn-machineagent-kafka stop
    chkconfig appdyn-machineagent-kafka off
    rm -f /etc/init.d/appdyn-machineagent-kafka
fi

if [ -d /bms/tools/appdynamics ];
then
    rm -rf /bms/tools/appdynamics
fi

if [ -d /bms/tools/appdynamics_agents ];
then
    rm -rf /bms/tools/appdynamics_agents
fi
