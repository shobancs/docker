# Monit Module Configuration
==========

You should use this module to install monit and create monit checks. Currently this
module can only create process type checks.

This class will install the monit rpm from the EPEL repository.

### Base Class Parameters

| parameter | default | optional |
|:---------:|:-------:|:--------:|
| mail_server | outbound.cisco.com | Y |
| alert_email | bmsadmin@cisco.com | Y |
| check_interval| 30s | Y |

**mail_server** - The server to send alert emails to. Must accept smtp connections
**alert_email** - The address the emails will be sent to.
** check_interval ** - How often checks should be run

### Base Class Usage
You only need to include the base class if you want to change one of the base
class parameter from the defaults. as it will be pulled in by dependancy whenever
 you create a check.

```
  class { '::monit':
    mail_server    => 'mx.example.tld',
    alert_email    => 'jsmith@inter.net',
    check_interval => '10s',  
  }

```

### Check Class Parameters
All parameters are required!

** ensure ** - Whether the check should exist or not. Values {present|absent]
** proc ** - The name of the process to check. The value should match the output of ps
** pid_file ** - The location of the pid file to check the process against
** start_prog ** - The path to a script to start your process. This script will be run as root
** stop_prog ** - The path to a script to stop your process. This script will be run as root


### Example Check Class
This check will check the output of ps -p $pid to make sure it is a java process.
If it is not a java process, monit will execute the command specified in the
start_prog value.

```
  monit::check { 'jenkins_master':
    ensure     => present,
    proc       => 'java',
    pid_file   => '/var/run/jenkins.pid',
    start_prog => '/bms/webapps/jenkins/executable/scripts/jenkins.sh start',
    stop_prog  => '/bms/webapps/jenkins/executable/scripts/jenkins.sh stop',
  }

```
