Artifactory Mission Control Module Configuration
================================================

You should use this module to install Artifactory Mission Control
and set it up as a service.  Essentially no configuration is done.
Configure the tool by manually editing the files in 
/bms/webapps/mission/control/etc/.

```
include ::jfrog_mc
```
