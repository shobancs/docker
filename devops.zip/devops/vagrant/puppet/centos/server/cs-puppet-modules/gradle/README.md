# gradle

#### Table of Contents

1. [Overview](#overview)
2. [Description](#module-description)
3. [Setup - The basics of getting started with gradle](#setup)
4. [Beginning with gradle](beginning-with-gradle)

## Overview

Puppet module to install supported Gradle versions.

## Module Description

Installs gradle via the profiles::buildtools 1.12, 2.14, 3.3

## Setup

/bms/tools/gradle/gradle-**version-number**

### Beginning with gradle

The very basic steps needed for a user to get the module up and running.
Included  profiles::buildtools
`
gradle::install { "gradle_${default_version}" :
  version => $default_version,
}
`
