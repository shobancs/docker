/**
 * This plugin performs a synchronous, two-phase commit of any artifact delete. It will
 * go to all replication targets configured for the repo the artifact is in and will 
 * perform a delete on each one before completing the delete request. If the delete fails
 * in any site, it will cancel the delete operation and return a 424 response code to the 
 * user. 
 * 
 * This plugin requires a configuration file to work. It will default to looking for the file
 * in /bms/config/meshDelete.json, but this can be changed to any file by overriding the 
 * system property 'meshReplication.config'.
**/

@Grab('org.codehaus.groovy.modules.http-builder:http-builder:0.7.1')

import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.Future
import java.util.concurrent.Callable
import java.util.Properties

import groovyx.net.http.HTTPBuilder
import groovy.json.JsonSlurper

import org.apache.http.HttpRequest
import org.apache.http.HttpRequestInterceptor
import org.apache.http.protocol.HttpContext
import org.artifactory.exception.CancelException

import static groovyx.net.http.ContentType.JSON
import static groovyx.net.http.Method.GET
import static groovyx.net.http.Method.DELETE

//config file location (cannot be relative, the CWD of the process is not ARTIFACTORY_HOME)
configLocation = System.getProperty('meshReplication.config') ?: '/bms/config/meshDelete.json'

//load config from file (put this in a closure to avoid namespace pollution)
config = {
  def configFile = new File(configLocation)
  if(!configFile.exists()){
    log.error("No config file found at ${configLocation}")
    throw new RuntimeException("No config file found at ${configLocation}")
  }
  return new JsonSlurper().parseText(configFile.text)
}.call()

//make sure required values are present
def missingValue = { 
  log.error("Missing required value in $configLocation: $it")
  throw new RuntimeException("Missing required value in $configLocation: $it") 
}

//credentials to perform deletes with
username   = config.username ?: except('username')
password   = config.password ?: except('password')

//time to wait for deletes to complete (in seconds)
timeout    = (config.timeout ?: 30) as Integer

//location of this artifactory server
self       = config.selfLocation ?: except('selfLocation')

//threadpool to manage deletes
deletePool = Executors.newFixedThreadPool((config.poolSize ?: 50) as Integer)

//manufacture an HTTP client
def httpClient(String url = null){
  def http = url == null ? new HTTPBuilder() : new HTTPBuilder(url)
  http.setHeaders([Authorization: "Basic " + ("$username:$password".bytes.encodeBase64().toString())])
  return http
}

//get replication config for a repo
def getReplicationConfig(String repoKey){
  log.debug("Looking up replication config ${self}/api/replications/${repoKey}")
  def replicationConfig
  httpClient().request("$self/api/replications/${repoKey}", GET, JSON) { 
    response.'404'   = { 
      log.warn("Unable to get replication config for $repoKey, assuming that it has none or is being deleted") 
    }
    response.success = {resp, json ->
      replicationConfig = json
    }
  }
  return replicationConfig ?: []
}

//delete an artifact in a remote site. returns one of the following status strings:
//  * deleted:     indicates that the delete occurred 
//  * not_present: indicates that the artifact was not in the remote path
//  * failed:      indicates that the delete failed
def deleteArtifact(String target, String path){
  def status = 'failed'

  try {
    httpClient().request("$target/$path", DELETE, JSON) {
      response.success = { status = 'deleted' }
      response.'404' = { status = 'not_present' }
      response.failure = { }
    }
  } catch(e) {
    log.error("Failed to delete $path in $target", e.message)
    log.debug("Stacktrace", e)
  }

  return status
}

storage {
  beforeDelete { item ->
    //ignore if this is from our reserved user because its another site executing this code
    if(security.currentUser().username != username){
      log.debug("Delete requested for $item.relPath in repo $item.repoKey by ${security.currentUser().username}") 
      def repo = repositories.getRepositoryConfiguration(item.repoKey)
      
      //perform two-phase commit of deletes on GitLFS repos
      if(repo.isEnableGitLfsSupport()){
        try{
          //delete in each target site before completing, using the threadpool to speed things up
          getReplicationConfig(repo.key).collect{ config->
            deletePool.submit({ return [url: config.url, status: deleteArtifact(config.url, item.relPath)] } as Callable)
          }.collect{ future->
            future.get(timeout, TimeUnit.SECONDS)
          }.each{ result->
            log.debug("Delete of $item.relPath at $result.url : $result.status")
            if(result.status == 'failed'){
              throw new CancelException("Could not delete $item.relPath at $result.url", 424)
            }
          }
        } catch(CancelException e){
          throw e
        } catch(e){
          log.error("Failed to delete $item.relPath in $item.repoKey", e.message)
          log.error("Stacktrace", e)
          throw new CancelException("Could not delete $item.relPath due to unexpected error: $e.message", 500)
        }
      }
    }
  }
}