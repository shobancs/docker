# ANT Module Configuration
==========

You should use this module to install the ant tool on Jenkins slaves. It only accepts a single
parameter, version, which causes the module to install the custon built rpm bms-ant-$version.

```
class { '::ant' :
  version => '1.9',
}
```

Included is a define that allows you to install multiple versions if desired.
Again, the only required parameter is "version".

Valid options for version are 1.8, 1.9, and 1.10.

```
define ant::install (
  $version,
) {
```

#### Example Profiles Manifest
```
# Install ant 1.8
ant::install { 'ant_1.9' :
  version = '1.9',
}

# install ant 1.9
ant::install { 'ant_1.9' :
  version = '1.9',
}

```
