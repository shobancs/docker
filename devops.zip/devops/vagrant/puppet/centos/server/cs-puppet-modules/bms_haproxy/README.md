# Puppet bms_haproxy

## Requirements

* [stdlib module](https://github.com/puppetlabs/puppetlabs-stdlib)

## Tested on...

* Debian 6 (Squeeze)
* Debian 7 (Wheezy)
* RedHat 6 (Santiago)
* RedHat 7 (Maipo)
* CentOS 6 (Final)
* CentOS 7 (Core)
* Scientific Linux 6 (Carbon)
* Scientific Linux 7 (Nitrogen)

## Example usage

### Install HAProxy

```
  include bms_haproxy
```

### Adjust configuration settings

```
  class { 'bms_haproxy':
    defaults_maxconn => '32768',
    global_chroot    => '/usr/share/haproxy',
    global_nbproc    => '2',
  }
```

### Create split frontend instance

```
bms_haproxy::instance { 'http-in':
  instance => 'frontend',
  bind     => '*:80',
  keywords => { 'default_backend' => 'pool1'},
}
```

### Create split frontend instance with ssl

```
bms_haproxy::instance { 'http-in':
  instance => 'frontend',
  bind_ssl => '*:443',
  ssl_cert => ['www.exaple.com.pem','example.com.pem','api.example.com.pem'],
  keywords => { 'default_backend' => 'pool1'},
}

bms_haproy::ssl_cert { 'www.example.com.pem':
  ensure => present,
}

bms_haproy::ssl_cert { 'api.example.com.pem':
  ensure => present,
}

bms_haproy::ssl_cert { 'example.com.pem':
  ensure => present,
}

```

### Create split frontend instance, with ACL

```
bms_haproxy::instance { 'http-in':
  instance  => 'frontend',
  bind      => '*:80',
  keywords  => { 'default_backend' => 'pool1' },
  acls      => { 'acl_pool1' => 'hdr(Host) -m sub -i pool1' },
}
```

### Create split frontend instance, with ACL, header manipulation

```
bms_haproxy::instance { 'http-in':
  instance   => 'frontend',
  bind       => '*:80',
  keywords   => { 'default_backend' => 'pool1' },
  acls       => { 'acl_pool1' => 'hdr(Host) -m sub -i pool1' },
  add_header => { 'X-Forwarded-Proto' => 'https if { ssl_fc }' },
  set_header => { 'X-Forwarded-Port' => '%[dst_port]' },
}
```


### Create split backend instance

```
bms_haproxy::instance { 'pool1':
  instance => 'backend',
  balance  => 'roundrobin',
  option   => [ 'http-server-close', 'checkcache' ],
  servers  => [
    'inst1 10.0.1.10:80'
    'inst2 10.0.1.20:80'
  ],
}
```

### Create combined listen instance

```
bms_haproxy::instance { 'pool2':
  instance => 'listen',
  bind     => '0.0.0.0:80',
  mode     => 'http',
  option   => 'persist',
  balance  => 'roundrobin',
  servers  => [
    'inst1 10.0.2.10:80',
    'inst2 10.0.2.20:80',
  ],
}
```

### Enable HAProxy stats page

```
class { 'bms_haproxy':
  stats_enable         => true,
  stats_listen_address => '0.0.0.0',
  stats_listen_port    => '8000',
}
```

### Enable HAProxy stats page with authentication

```
class { 'bms_haproxy':
  stats_enable      => true,
  stats_auth_enable => true,
  stats_auth_user   => 'haproxy',
  stats_auth_pass   => 'haproxy',
}
```

### Add custom logging options to manage log fields

```
bms_haproxy::instance { 'pool2':
  instance => 'listen',
  capture  => [
    'request header Host len 40',
    'request header X-Forwarded-For len 50',
    'request header Accept-Language len 50',
    'request header Referer len 200',
    'request header User-Agent len 200',
    'response header Content-Type len 30',
    'response header Content-Encoding len 10',
    'response header Cache-Control len 200',
    'response header Last-Modified len 200',
  ],
```

### Manage package repository

```
class { 'bms_haproxy':
  manage_repo => true,
}
```
