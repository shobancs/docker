# HTTPD Module Configuration
==========

You should use this module to create configurations for HTTP applications. It only accepts a single
parameter, use_ssl, which causes the module to install mod_ssl and create directories to hold ssl keys
and certificates.   

```
class { '::httpd' :
  use_ssl => [true|false], #<-- optional boolean value
}
```

Included is a define that allows you to setup a virtual host. This define can be called multiple times per host.
There are lots of values that have sane defaults. The only required values are listen_port and doc_root.

Unfortunately, this module will not create the doc_root folder and will not automatically populate it
with your website. That will need to be done in a different manifest.   

```
define httpd::vhost (
  $listen_port,
  $doc_root,
  $options = ["Indexes", "FollowSymLinks", "MultiViews"],
  $overrides = ["None"],
  $use_ssl = false,
  $ssl_crt = undef,
  $ssl_key = undef,
  $ssl_protocols   = ["all","-SSLv3","-TLSv1"],
  $ssl_ciphersuite = ["+HIGH","!LOW","!SSLv3","!TLSv1","!RC4","!MD5","!aNULL","!eNULL","!3DES","!EXP","!PSK","!DSS","!RC4","!SEED","!IDEA","!ECDSA"],
) {
```

#### Example Profiles Manifest


```
# http_server.pp

class profiles::http_server {
  include ::bms_repos::bms_yum
  include ::encgi_users::pdsint

  class { '::httpd' :
    use_ssl => true,
  }

  httpd::vhost { 'mysite.example.com' :
    listen_port => '80',
    doc_root    => '/var/www/html',
  }
}
```
