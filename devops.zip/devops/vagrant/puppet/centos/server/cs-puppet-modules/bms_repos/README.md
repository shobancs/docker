# BMS Repository Configuration
==========

This module creates a Yum configuration for the specified BMS Yum repositories.

#### Configuration:

Update params.pp with the yum configurations for each repository that will be provided. If enabling gpgcheck  
be sure to set the gpgkey name and add the key to the files directory.

#### Usage:

##### Via require

Simply require the repo you need to pull from. The repo environment i.e. dev vs prod will be determined by the environment the host is in in Foreman. 

For the bms_yum repo:

```
require bms_repos::bms_yum
```

And for Orion:
```
require bms_repos::orion_yum
```

##### Via Foreman

Pass an array with either a string specifying the repo name or a hash
with a name parameter and an enabled parameter set to 1 or 0.
  
```
node 'node1' {
  class bms_repos{ repos => ['bms-dev-yum', { name => "bms-prod-yum", enabled => 0 }] }
}
```

 In Foreman the repos parameter is assigned with a json string e.g.:

```javascript
["bms-prod-yum", "bms-orion-prod"]
```  
```javascript
[ { "name": "bms-prod-yum", "enabled": 0 }, "bmn-orion-prod"]
```
