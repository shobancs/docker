# Seleniumbox Module Configuration
==========

You should use this module to install a selenium box hub or node software. This module will spin up a
docker container running the requested version. This module takes a few arguments but has sane defaults.
There is only one required parameter, the "type" value. The only accepted values are [hub|node].

This module is also written to assume a hub and node install would never happen on the same physical/virtual server


```
class { '::seleniumbox' :
  type     => 'hub',
  version  => '1.23.4',   #<-- optional
  e34_user => "username", #<-- optional
  e34_pass => "passw0rd", #<-- optional
}
```

#### Example Profiles Manifest


```
# sebox_hub.pp

class profiles::sebox_hub {
  include ::encgi_users::pdsint
  include ::docker

class {'::seleniumbox' :
  type    => 'hub',
  version => '1.23.4',
}

```
