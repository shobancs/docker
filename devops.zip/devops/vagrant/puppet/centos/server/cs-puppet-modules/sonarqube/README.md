#### Table of Contents

1. [Overview](#overview)
2. [Module Description - What the module does and why it is useful](#module-description)


## Overview

Installs SonarQube

## Module Description

Installs sonarqube in the /bms/webapps/sonarqube directory

#Creates a symlink
```
 /bms/webapps/sonarqube/sonarqube -> /bms/webapps/<installed-rpm>

e.g
/bms/webapps/sonarqube/sonarqube -> /bms/webapps/sonarqube/sonarqube-<version>
 ```


```
Database: bmsstg
Host: rtp-dbsl-cibld
SID: BMSSTG
Port: 1521
Quota: 1GB
Concurrent sessions limit: 30

```
