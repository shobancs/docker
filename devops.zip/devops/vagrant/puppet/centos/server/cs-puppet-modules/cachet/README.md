# Puppet Cachet

Cachet is an application that integrate with monitoring tool It displays service status  .

## Requirements

* [stdlib module](https://github.com/puppetlabs/puppetlabs-stdlib)

## Tested on...

* RedHat 6 (Santiago)
* RedHat 7 (Maipo)
* CentOS 6 (Final)
* CentOS 7 (Core)
* Scientific Linux 6 (Carbon)
* Scientific Linux 7 (Nitrogen)

## Example usage

### Install cachet

```
  class { 'cachet':
    min_threads     => '10',
    max_threads     => '20',
    listen_port     => '7700',
    frontend_url    => 'http://artifactory.example.com',
    artifactory_url => 'localhost:6090'
  }
```
