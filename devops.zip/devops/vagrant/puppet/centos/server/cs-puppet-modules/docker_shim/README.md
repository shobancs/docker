# Puppet docker_shim

Docker_shim is a project that provides a correct Docker v2 registry API to end-users,
while performing subtle manipulations to request to allow it work properly with Artifactory.

## Requirements

* [stdlib module](https://github.com/puppetlabs/puppetlabs-stdlib)

## Tested on...

* RedHat 6 (Santiago)
* RedHat 7 (Maipo)
* CentOS 6 (Final)
* CentOS 7 (Core)
* Scientific Linux 6 (Carbon)
* Scientific Linux 7 (Nitrogen)

## Example usage

### Install docker_shim

```
  class { 'docker_shim':
    min_threads     => '10',
    max_threads     => '20',
    listen_port     => '7700',
    frontend_url    => 'http://artifactory.example.com',
    artifactory_url => 'localhost:6090'
  }
```
