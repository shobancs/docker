# reset password http://erwan.com/en/2014/10/06/foreman-lost-reset-password/

sudo foreman-rake permissions:reset